package com.sharepoint.bancodebogota.pageObject;

import net.thucydides.core.annotations.DefaultUrl;

import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

@DefaultUrl("URL reservas")
public class PaginaInicialPageObject extends PageObject {

    By BtnPiso = By.xpath("//span[text()='Piso 10']");
    By iFrame = By.xpath("//iframe[@src='https://outlook.office365.com/owa/calendar/ReservadeSalasDG@bancodebogota.com.co/bookings/']");
    By btnCambioMes = By.xpath("//*[@data-icon-name='ChevronRightMed']");
    By btnDia = By.xpath("//div[@data-value='2024-12-04T00:00:00.000Z']");
    By sltSala = By.xpath("//*[@data-icon-name='ChevronDownMed']");
    By lblSala = By.xpath("//span[text()='Sala 4 Piso 10 ']");
    By lblHora = By.xpath("//label[@for='timeslot_0']");
    By txtMotivo  = By.xpath("//input[@id='75a7f4d2-08c5-46d5-b302-1ac9b5f95202']");
    By btnReserva  = By.xpath("//button[@aria-label='Reservar']");
    By btnAceptar  = By.xpath("//div[@class='Sq2Eo']/button");
    By btnNuevaReserva  = By.xpath("//button[@class='HQkBA xTALn']");
    By lblMensanje = By.xpath("//h1[text()='Reserva de Salas D.G.']");






    public By getBtnPiso() {
        return BtnPiso;
    }
    public By getiFrame() {
        return iFrame;
    }
    public By getBtnDia() {
        return btnDia;
    }
    public By getBtnCambioMes() {
        return btnCambioMes;
    }
    public By getSltSala() {
        return sltSala;
    }
    public By getLblSala() {
        return lblSala;
    }
    public By getLblHora() {
        return lblHora;
    }
    public By getTtxtMotivo() {
        return txtMotivo;
    }
    public By getBtnReserva() {
        return btnReserva;
    }
    public By getBtnAceptar() {
        return btnAceptar;
    }
    public By getBtnNuevaReserva() {
        return btnNuevaReserva;
    }
    public By getlblMensanje() {
        return lblMensanje;
    }
}

