package com.sharepoint.bancodebogota.steps;

import com.sharepoint.bancodebogota.pageObject.PaginaInicialPageObject;
import com.sharepoint.bancodebogota.utils.EsperaImplicita;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.regex.Matcher;

public class PaginaInicialStep  {

    PaginaInicialPageObject paginaInicialPageObject = new PaginaInicialPageObject();
    EsperaImplicita esperaImplicita = new EsperaImplicita();
    @Step
    public void abrirNavegador(){
        paginaInicialPageObject.open();
        System.out.println("Prueba");
        paginaInicialPageObject.getDriver().switchTo().frame(paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getiFrame()));
    }
    @Step
    public void seleccionarFecha(){

        for (int i = 0; i <= 9; i++) {
            //Si se cambia de mes de cambiar el mes
            esperaImplicita.esperaImplicita(2);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnCambioMes()).click();
            esperaImplicita.esperaImplicita(2);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnCambioMes()).click();
            esperaImplicita.esperaImplicita(2);
            //
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnPiso()).click();
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getSltSala()).click();
            esperaImplicita.esperaImplicita(2);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getLblSala()).click();
            esperaImplicita.esperaImplicita(16);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnDia()).click();
            //esperaImplicita.esperaImplicita(10);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getLblHora()).click();
            //paginaInicialPageObject.getDriver().findElement(By.xpath("//label[@for='timeslot_"+i+"']")).click();
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getTtxtMotivo()).sendKeys("Reserva equipo CoE");
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnReserva()).click();
            esperaImplicita.esperaImplicita(3);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnAceptar()).click();
            esperaImplicita.esperaImplicita(3);
            paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getBtnNuevaReserva()).click();
        }
    }
    @Step
    public void mensajeFinal(){
        esperaImplicita.esperaImplicita(2);
        Assert.assertThat(paginaInicialPageObject.getDriver().findElement(paginaInicialPageObject.getlblMensanje())
                .isDisplayed(), Matchers.is(true));

    }
}
