package com.sharepoint.bancodebogota.stepDefinions;

import com.sharepoint.bancodebogota.pageObject.PaginaInicialPageObject;
import com.sharepoint.bancodebogota.steps.PaginaInicialStep;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.thucydides.core.annotations.Steps;



public class SeparaSalaStepDefinition {
    @Steps
    PaginaInicialStep paginaInicialStep ;

    @Dado("que el usuaro ingresa a la pagina de reservas")
    public void queElUsuaroIngresaALaPaginaDeReservas() {
        paginaInicialStep.abrirNavegador();
    }
    @Cuando("se escoga la fecha y sala")
    public void seEscogaLaFechaYSala() {
        paginaInicialStep.seleccionarFecha();
    }
    @Entonces("El sistea separa la sala")
    public void elSisteaSeparaLaSala() {
            paginaInicialStep.mensajeFinal();
    }
}
