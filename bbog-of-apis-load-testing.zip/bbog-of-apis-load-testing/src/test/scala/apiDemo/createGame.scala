package apiDemo

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class createGame extends Simulation {

  val httpConfig = http.baseUrl("https://videogamedb.uk/api")
    .acceptHeader("application/json")
    .contentTypeHeader("application/json")

  val scenario1 = scenario("Crear Juego")
    .exec(
      http("Solicitar token")
        .post("/authenticate")
        .body(StringBody("{\n  \"password\": \"admin\",\n  \"username\": \"admin\"\n}"))
        .check(jsonPath("$.token").saveAs("token"))
        .check(status.is(200))
    )
    .exec(
      http("Crear juego")
        .post("/videogame")
        .header("Authorization","Bearer #{token}")
        .body(StringBody("{\n  \"category\": \"string\",\n  \"id\": 0,\n  \"name\": \"string\",\n  \"rating\": \"string\",\n  \"releaseDate\": \"string\",\n  \"reviewScore\": 0\n}"))
        .check(status.is(200))
    )

  setUp(
    scenario1.inject(rampUsers(10).during(5)).protocols(httpConfig)
  )

}
