package apiDemo

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class GetGameWithFeeder extends Simulation {

  val httpConfig = http.baseUrl("https://videogamedb.uk/api")
    .acceptHeader("application/json")

  var archivo = csv("data/datosJuegos.csv").circular

  val scenario1 = scenario("Obtener un juego por id")
    .feed(archivo)
    .exec(
      http("GET one game ${gameId}")
        .get("/videogame/#${gameId}")
        .check(status.is(200))
        .check(bodyString.saveAs("response"))
    )
    .exec{
      session => println(session("response").as[String]);session
    }

  setUp(
    scenario1.inject(atOnceUsers(23)).protocols(httpConfig)
  )

}