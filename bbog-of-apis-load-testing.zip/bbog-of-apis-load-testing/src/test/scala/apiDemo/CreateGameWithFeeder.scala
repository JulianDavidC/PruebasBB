package apiDemo

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class CreateGameWithFeeder extends Simulation {

  val httpConfig = http.baseUrl("https://videogamedb.uk/api")
    .acceptHeader("application/json")
    .contentTypeHeader("application/json")

  var archivo = csv("data/crearJuego.csv").circular

  val scenario1 = scenario("Crear juego con diferente ID")
    .feed(archivo)
    .exec(
      http("Solicitar Token")
        .post("/authenticate")
        .body(StringBody("{\n  \"password\": \"admin\",\n  \"username\": \"admin\"\n}"))
        .check(jsonPath("$.token").saveAs("token"))
        .check(status.is(200))
    )
    .exec(
      http("Crear juego #{name}")
        .post("/videogame")
        .header("Authorization","Bearer #{token}")
        .body(ElFileBody("data/body.json"))
        .check(status.is(200))
        .check(bodyString.saveAs("response"))
    )
    .exec{
      session => println(session("response").as[String]);session
    }
  setUp(
    scenario1.inject(rampUsers(10).during(5)).protocols(httpConfig)
  )
}
