package apiDemo

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class getSingleGame extends Simulation  {

  val httpConfig = http.baseUrl("https://videogamedb.uk/api")
    .acceptHeader("application/json")

  val scenario1 = scenario("Obtener un juego por id")
    .exec(
      http("GET one games")
        .get("/videogame/2")
        .check(status.is(200))
    )

  setUp(
    scenario1.inject(constantUsersPerSec(1).during(5)).protocols(httpConfig)
  )

}
