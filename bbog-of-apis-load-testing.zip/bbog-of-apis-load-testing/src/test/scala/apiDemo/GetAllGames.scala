package apiDemo

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class GetAllGames extends Simulation {

  val httpConfig = http.baseUrl("https://videogamedb.uk/api")
    .acceptHeader("application/json")

  val scenario1 = scenario("Test obtener todos los juegos de base de datos")
    .exec(
      http("GET games")
        .get("/videogame")
        .check(status.is(200))
    )

  setUp(
    scenario1.inject(atOnceUsers(15)).protocols(httpConfig)
  )

}
